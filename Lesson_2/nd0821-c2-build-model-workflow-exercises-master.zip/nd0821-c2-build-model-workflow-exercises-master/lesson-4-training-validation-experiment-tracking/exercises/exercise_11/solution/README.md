There isn't really a solution here, the student just needs to run experiments and note results
on W&B