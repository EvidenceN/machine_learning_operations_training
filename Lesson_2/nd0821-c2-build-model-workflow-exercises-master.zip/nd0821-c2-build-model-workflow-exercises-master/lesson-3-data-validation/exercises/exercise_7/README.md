# Instructions
In this exercise you will apply deterministic tests to the cleaned dataset from exercise 5.

# Steps

Complete the tests in ``test_data.py`` file which contains the tests for ``pytest``. Instructions
are in the file.

Please ignore the deprecation warning you might get, related to ``wandb``.